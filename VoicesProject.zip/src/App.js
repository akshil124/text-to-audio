import logo from './logo.svg';
import React from "react";
import './App.css';
import Blog from "../src/Component/index"
function App() {
  return (
    <Blog/>
  );
}

export default App;
